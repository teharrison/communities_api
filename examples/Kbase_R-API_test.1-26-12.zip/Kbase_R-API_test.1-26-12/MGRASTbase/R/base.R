
### define globals

shew <- function (a) { print (paste (typeof (a), mode (a), class (a))); summary (a) }
.m.URL <- "http://api.metagenomics.anl.gov"

### some valid parameters, for testing

.m.project <- "92"
.m.sample <- "mgs3482"
.m.library <- "mgl3482.4"
.m.metagenome <- "mgm4440282.3"
.m.abundance.profile <- "mgm4440282.3"
.m.sequence <- NULL
.m.namespaces <- c ("M5NR","SwissProt","GenBank","IMG","SEED","TrEMBL","RefSeq","PATRIC","eggNOG","KEGG","RDP","Greengenes","LSU","SSU")

mgrastQuery <- function (
	resource,
	attribute = NULL,
	value = NULL
) { warning ("Unimplemented function" ); return (NULL) }


mgrastAnnotationQuery <- function (
	md5,
	namespace = c ("M5NR","SwissProt","GenBank","IMG","SEED","TrEMBL","RefSeq","PATRIC","eggNOG","KEGG","RDP","Greengenes","LSU","SSU")
) { warning ("Unimplemented function"); return (NULL) }


mgrastGet <- function( 
	resource = c ("project", "sample", "library", "metagenome", "abundance.profile", "sequence.set", "sequence", "matrix" ),
	ID = NULL,
        param = NULL,
	verbose = TRUE,
	trim = TRUE, 
        site = c ("prod") ) {

URL.base <- switch (site, prod = .m.URL)
URL.str <- switch (resource, 
  project = 
    paste (URL.base, "project/", ID, sep = "" ),
  sample = 
    paste (URL.base, "sample/", ID, sep = ""),
  library = 
    paste (URL.base, "library/", ID, sep = ""),
  metagenome = 
    (if (is.null (ID)) { warning ("metagenome requires ID specification"); return (NULL) } 
    else paste (URL.base, "metagenome/", ID, sep = "")),
  abundance.profile = 
    (if (is.null (ID)) { warning ("abundance profile requires ID specification"); return (NULL) } 
    else paste (URL.base, "abundance_profile/", ID, sep = "")),
  sequence.set = 
    { warning ("Unimplemented option"); return (NULL) },
  sequence = 
    { warning ("Unimplemented option"); return (NULL) },
  matrix = {
    ID.str = character(0)
    for (x in ID) ID.str <- paste (x, ID.str, sep=";")
    param.str = character(0)
    for (x in param) param.str <- paste (param.str, x, sep="/")
    paste (URL.base, "matrix/", ID.str, param.str, sep = "")
  },
  { warning ("Invalid option"); return (NULL) } )

if (verbose) message ("retrieving from: ", URL.str)
connection <- url (URL.str)
read.obj <- readLines (connection, warn = FALSE)
close (connection)

JSON.obj <- fromJSON (read.obj, asText = TRUE)
if (verbose) message (length (unlist (JSON.obj)), " JSON elements parsed")

obj = switch (resource, 
  project = JSON.obj,
  sample = JSON.obj, 
  library = JSON.obj,
  metagenome = JSON.obj,
  abundance.profile = JSON.obj,
  sequence.set = JSON.obj,
  sequence = JSON.obj,
  matrix =
    (if (length (grep ("/format/plain", param.str) == 1)) {
      temp.file <- tempfile()
      writeLines (read.obj, temp.file)
      x <- read.table (temp.file, header=TRUE, row.names=1, sep="\t", quote="", comment.char="")
      unlink (temp.file)
      x
    }
    else JSON.obj) )
if (verbose) message ("returning edited object")

invisible (obj)
}




#
#mgrastGet( resource = "abundance.profile", ID= "mgm4440282.3", verbose = TRUE )
#
#temp.file <- ....
#
#download.file( req.url, temp.file, method="curl", mode="wb" )
#
#
#MAIN DATA OBJECTS (there are others)
#
#http://$KBAU/project/{ID}/ 
#http://$KBAU/sample/{ID}/1 
#http://$KBAU/library/{ID}/ 
#http://$KBAU/sequenceSet/{ID}/ 
#http://$KBAU/abundance_profile/{ID}/ 
#http://$KBAU/abundance_profile/{ID}/source/{source name} 
#http://$KBAU/abundance_profile/{ID}/source/{source name}/type/{ontology | taxonomy}
#
#download.file("http://dev.metagenomics.anl.gov/api.cgi/project","mgrast.projects")
#fromJSON("mgrast.projects")
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/project")
#T <- readLines(U)
#mgrast.projects <- fromJSON( T )
#unlist( mgrast.projects[[1]] )
#close( U )
#
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/project/92")
#T <- readLines(U)
#mgrast.project.92 <- fromJSON(T)
#close( U )
#names(mgrast.project.92$
#
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/library")
#T <- readLines(U)
#mgrast.libraries <- fromJSON(T)
#close( U )
#
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/sample")
#T <- readLines(U)
#mgrast.samples <- fromJSON(T)
#close( U )
#unlist (mgrast.samples[[1]])
#
#
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/sample/mgs1224")
#T <- readLines(U)
#mgrast.sample.1224 <- fromJSON(T)
#close( U )
#names(mgrast.sample.1224$metadata)
#
#
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/sequenceSet/92")
#T <- readLines(U)
#mgrast.sample.1224 <- fromJSON(T)
#close( U )
#names(mgrast.sample.1224$metadata)
#
#U <- url("http://dev.metagenomics.anl.gov/api.cgi/abundance_profile/mgm4441102.3")
#T <- readLines(U)
#ap <- fromJSON(T)
#close( U )
#
#
