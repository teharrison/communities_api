hold <- function (messg = NULL, cmd = NULL) { message (messg); if (!is.null (cmd)) writeLines (paste (options ("prompt"), cmd), sep=""); invisible (readLines (n=1, warn=FALSE))}

source("heatmap_dendrogram.r")
source("plot_pco.r")
source("preprocessing.r")

hold ("\n### Researchers can retrieve output from MG-RAST and analyze it interatively at the R console.\n### First, install the base MG-RAST package and dependencies:\n###\n### (Press return to execute each command)\n", "install.packages (MGRASTbase)")
install.packages ("RJSONIO", repos = "http://cran.wustl.edu")
message( "" )
install.packages ("MGRASTbase.tar", repos = NULL, type = "source")

hold ("\n### And now load it:\n", "library (MGRASTbase)")
library (MGRASTbase)

hold ("\n### Now retrieve a metagenome header into an R object:\n", "mgm <- mgrastGet (resource = \"metagenome\", ID = \"4443360.3\")")
mgm <- mgrastGet (resource = "metagenome", ID = "mgm4443360.3", site = "prod")

hold ("\n### We can browse the metagenome metadata:\n", "mgm$metadata")
print.data.frame (as.data.frame (mgm$metadata [-c(7,9,21,31)]), right=FALSE)

hold ("\n### We just retrieved a header, only.  For numerical data, we retrieve some abundance counts:\n", "taxa <- mgrastGet (resource = \"matrix\", ID = c (\"4443360.3\",\"4443361.3\",\"4443362.3\",\"4443363.3\",\"4443364.3\",\"4443365.3\",\"4443366.3\",\"4443367.3\",\"4443368.3\"), param = c (\"source\", \"M5NR\"))")
taxa <- suppressWarnings(mgrastGet (resource = "matrix", ID = c ("4443360.3","4443361.3","4443362.3","4443363.3","4443364.3","4443365.3","4443366.3","4443367.3","4443368.3"), param = c ("source", "M5NR", "group_level", "species", "format", "plain"), site = "prod"))


hold ("\n### The returned object is a data frame (matrix) with counts for nine metagenomes.  The column labels are MG-RAST IDs, as follows:\n", "colnames (taxa)")
print (colnames (taxa))
hold ("\n### Here are the first few row labels, which are taxa:\n", "rownames (taxa) [1:20]")
print (rownames (taxa) [1:20])
hold ("\n### And the overall dimensions of the data frame are:\n", "dim (taxa)")
print (dim (taxa))
hold ("\n### A \"five-number\" summary of the abundance data will show mostly zeros, naturally:\n", "summary (taxa)")
print (summary (taxa))
hold ("\n### We can select rows with high abundance:\n", "subset (taxa, X4443364.3 > 8000)")
print (subset (taxa, X4443364.3 > 8000 ))



hold("\n### Users can save their data - to script custom analyses locally :\n", "write.table(taxa, file = \"my_taxa_abundance_profile\", col.names=NA, row.names = TRUE, sep=\"\t\", quote=FALSE)")
write.table(taxa, file = "my_taxa_abundance_profile", col.names=NA, row.names = TRUE, sep="\t", quote=FALSE)
#system("head -n 1000 my_taxa_abundance_profile > my_taxa_abundance_profile")
system("open my_taxa_abundance_profile")

hold("\n### Or use R versions of the MGRAST analysis tools:\n### Preprocessing:", "Kbase_preprocessing(file_in = \"my_taxa_abundance_profile\")")
Kbase_preprocessing(file_in = "my_taxa_abundance_profile")
system("open my_taxa_abundance_profile.BOXPLOTS.png")

hold("\n### Or use R versions of the MGRAST analysis tools:\n### PCoA:", "Kbase_plot_pco(file_in = \"my_taxa_abundance_profile.preprocessed_data\")")
Kbase_plot_pco(file_in = "my_taxa_abundance_profile.preprocessed_data")
system("open my_taxa_abundance_profile.preprocessed_data.bray-curtis.PCoA")
#system("open -a /applications/Microsoft\ Office\ 2011/Microsoft\ Excel.app/ my_taxa_abundance_profile.preprocessed_data.bray-curtis.PCoA")

#system("head -n 1000 my_taxa_abundance_profile.preprocessed_data > my_taxa_abundance_profile.preprocessed_data.edit")
hold("\n### Or use R versions of the MGRAST analysis tools:\n### Heatmap-Dendrogram (this will take a couple minutes):", "Kbase_heatmap_dendrogram(file_in = \"my_taxa_abundance_profile.preprocessed_data\")")
Kbase_heatmap_dendrogram(file_in = "my_taxa_abundance_profile.preprocessed_data")
system("open my_taxa_abundance_profile.preprocessed_data.HD.png ")

#hold("\n### Or use R versions of the MGRAST analysis tools:\n ### Heatmap-Dendrogram:", "MGRAST_heatmap_dendrogram(file_in = \"my_taxa_abundance_profile.preprocessed_data\")")
#MGRAST_heatmap_dendrogram(file_in = "my_taxa_abundance_profile.preprocessed_data")
#system("open my_taxa_abundance_profile.preprocessed_data.HD.png ")

message (
         "\n\n### etc.  These and other features have a lot more options than shown here.\n### Researchers are enabled to script custom analyses locally\n### with R's extensive functionality and relevant add-on packages."
         )




## valid parameters (for param):
## format: [sparse_matrix, plain] default: sparse_matrix
## result_column: [abundance, evalue, length, identity] default: abundance
## show_hierarchy: [0,1] default: 0
## type: [taxonomy, functional] default: taxonomy
## source: [RefSeq,...] default: RefSeq
## group_level: for taxonomy: [domain, phylum, class, order, family, genus, species, strain] default: strain
## for functional: [level1, level2, level3, function] default: function

#hold ("\n### Now we install and load the MG-RAST tools:\n", "install.packages (MGRASTtools)")
#install.packages ("MGRASTtools", repos = NULL, type = "source")

#hold ("", "library (MGRASTtools)")
#library (MGRASTtools)

# Functionality similar to what is presently available through the WWW GUI will be in package MGRASTtools:

#?MGRASTtools

# Some of it is up and running:

#mgrastPCA ( mgm )
#mgrastHeatmapDendrogram ( mgm )

# Researchers can combine the MG-RAST tools with their own analyses, maintaining scripts locally.
# (And analyses can be automated, using R in batch mode.)
