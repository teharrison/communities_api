###
### FULLFILE.R - Build full filename from parts
###


##-----------------------------------------------------------------------------
fullfile <- function(...) {
    return(file.path(...))
}

