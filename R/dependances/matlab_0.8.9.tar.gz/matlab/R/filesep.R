###
### FILESEP.R - Directory separator for this platform
###


##-----------------------------------------------------------------------------
filesep <- .Platform$file.sep

