###
### CEIL.R - Rounds to the nearest integer
###


##-----------------------------------------------------------------------------
ceil <- function(x) {
    return(ceiling(x))
}

