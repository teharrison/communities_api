###
### PATHSEP.R - Path separator for this platform
###


##-----------------------------------------------------------------------------
pathsep <- .Platform$path.sep

