residuals.mgram <- function(object, ...)
{
   # for S3 "neatness"
   object$resids
}
