.First.lib <- function(lib, pkg)

{
library.dynam("ecodist", pkg, lib)
library(stats)
}

